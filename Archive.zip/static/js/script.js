// var a = 0;
// var add = function(valueToAdd) {
//     a += valueToAdd;
//     document.getElementById('display').innerHTML = a;
// }

// var reset = function() {
//     a = 0;
//     document.getElementById('display').innerHTML = 0;
// }

// var addButton = document.querySelector("#add");
// var resetButton = document.querySelector("#reset");

// addButton.addEventListener("click", function() {
//     add(1);
// })




// resetButton.addEventListener("click", function() {
//     reset();
// })

// var count = 0;
// var click = document.getElementById("click");
// var disp = document.getElementById("display");

// click.onclick = function () {
// count++;
// disp.innerHTML = count;
// }